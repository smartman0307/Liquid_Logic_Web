/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("device-desc.xml", 
		"URL=http://192.168.1.121:8008/ssdp/device-desc.xml", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/xml", 
		"Referer=", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("desc", 
		"URL=http://192.168.1.73:60000/upnp/dev/00e91b8d-743c-3912-a302-2d1eb6bf14a6/desc", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/xml", 
		"Referer=", 
		"Snapshot=t17.inf", 
		LAST);

	lr_think_time(9);

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=102", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(13);

	web_url("generate_204", 
		"URL=http://www.gstatic.com/generate_204", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("CONSENT=YES+srp.gws-20220309-0-RC1.en+FX+789; DOMAIN=accounts.google.com");

	web_add_cookie("SMSV=ADHTe-B4G-EUhOfBjhjdOeXkcOFYt75ltHy49Xfij7dPqc-VnyKV_zxKzrcPLhRclH1_KPS-Oj0enZZqMivCZQnWUqmGgQJYJqp_TjfWpU0dU2gmufV1jnI; DOMAIN=accounts.google.com");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI5G0f8zjQ4kd9MOXlvLhCKr5y0crYddefAPzYPk78Q8YxMqc-neTmn1fEn8WFaNwdmi2cVPnK4WqIoJGOYs1UIUACGIn1sXfBPKMw3SuKPKIsRAOGIO_T4bD5YDXhzudcXqQpY5bQLmsqEwAPNPxzEIZTBE2w; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIgJUB; DOMAIN=accounts.google.com");

	web_add_cookie("SID=KAiVm3UzVuOJuf2NKRVgfoxFS-u2vQCkN-JsGkS1YWeAxW80gefm6564FEidtQlePZ6aWw.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSID=KAiVm3UzVuOJuf2NKRVgfoxFS-u2vQCkN-JsGkS1YWeAxW80qhdDrfl7eUfZvzSh0fDPuQ.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSID=KAiVm3UzVuOJuf2NKRVgfoxFS-u2vQCkN-JsGkS1YWeAxW801UHRnxMOvW39NBL7FMIp5g.; DOMAIN=accounts.google.com");

	web_add_cookie("HSID=A4i43MtkFsn-5rDjq; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=AryQjyxC0uDaQB_Ys; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=rcus5smFFJAimV4z/AWmKWjrHATnrU0OK4; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=84vCLABwt5BDAF6-/ALsBluzVn7x21eM7d; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PAPISID=84vCLABwt5BDAF6-/ALsBluzVn7x21eM7d; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PAPISID=84vCLABwt5BDAF6-/ALsBluzVn7x21eM7d; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=o.chat.google.com|o.mail.google.com|o.meet.google.com|s.GB|s.youtube:KAiVm6s_Yt0p7N_1Hy1fbBklZfqGu2veGp23jwKAOSnYn9ygHRz6UUM--bllhn1SYrIjFQ.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-1PLSID=o.chat.google.com|o.mail.google.com|o.meet.google.com|s.GB|s.youtube:KAiVm6s_Yt0p7N_1Hy1fbBklZfqGu2veGp23jwKAOSnYn9ygsHlCiNHLTQoTfLOnsoIPPQ.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-3PLSID=o.chat.google.com|o.mail.google.com|o.meet.google.com|s.GB|s.youtube:KAiVm6s_Yt0p7N_1Hy1fbBklZfqGu2veGp23jwKAOSnYn9yglhSSNmxQgXn5PWk9s66LLQ.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-GAPS=1:xxgua_tA4bE1BzHZw01SDLojSSOgiJIC_8h_kEE0i-_gxiYr1cGAOxifCgyrdgeAvQYvbnEYF0XtcwuxA8bITBIMP0UDsg:87VnFMmFIDHQr3Gg; DOMAIN=accounts.google.com");

	web_add_cookie("AEC=AakniGNKqPat69vzfxbDnUdyO-IXQaTmHLsPYfhpmj4c4DCSfAC9xTYIdA; DOMAIN=accounts.google.com");

	web_add_cookie("PREF=ID=2302c7bc12d2a0ce:FF=0:TM=1654892314:LM=1654892314:V=1:S=ui-LbW7d9QWz6idH; DOMAIN=accounts.google.com");

	web_add_cookie("NID=511=FvToV6m71J3lg3F9JD9DyKdWIRzS5Y9Psr0Hf1DQ7OYxws6ZjiIC_724Qy0JUU9N1nrrZKHhH1r-52f5DJRY3-wT8aC7o6hNmCsp3iQYKofZ__zy0kAsWLUPIQw7wz84z0qbl1uY1o6o3TEixEi7eWCAkXJbDu4gXwDEN1SQvVS2Vo-gM5PYEQMqua8LN8IeNDEuP9cz1D_Rj3a7hz3BSDPmn0uFNZsvmQU8tttHEVYIfmtkRSLJYSEAXqwjvFaL9Y6XjjZRRyTIE55kAfHm9gg91gznNfRYEQUb8-kIPXtHBzpUrpwh; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2022-06-11-09; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=AJi4QfHqKsobIZeE1h-IgGdEEOkyweY3ljoOzoOURXnP2Hf93ldEPkirwEVbC1j03QUQ1UZbog; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDCC=AJi4QfGVuTPeyIjp2A7IBUn0Xmmm-lWQaitxjkSizoFhC3rdcUb_q3FDNCdBFwbPJvtiWX0X3A; DOMAIN=accounts.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	return 0;
}